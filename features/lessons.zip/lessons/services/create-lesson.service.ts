import {
  addDoc,
  collection,
  serverTimestamp,
} from "firebase/firestore";

import { db } from "@/lib/firebase/config";

import type { CreateLessonInput } from "../validators";

export async function createLesson(
  data: CreateLessonInput
): Promise<string> {
  const docRef = await addDoc(
    collection(db, "lessons"),
    {
      ...data,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }
  );

  return docRef.id;
}