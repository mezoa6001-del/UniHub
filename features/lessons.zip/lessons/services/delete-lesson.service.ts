import { deleteDoc, doc } from "firebase/firestore";

import { db } from "@/lib/firebase/config";

export async function deleteLesson(
  lessonId: string
): Promise<void> {
  await deleteDoc(doc(db, "lessons", lessonId));
}