import {
  collection,
  getDocs,
  orderBy,
  query,
  where,
} from "firebase/firestore";

import { db } from "@/lib/firebase/config";

import type { Lesson } from "../types";

export async function listLessons(
  chapterId: string
): Promise<Lesson[]> {
  const q = query(
    collection(db, "lessons"),
    where("chapterId", "==", chapterId),
    orderBy("order", "asc")
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...(doc.data() as Omit<Lesson, "id">),
  }));
}