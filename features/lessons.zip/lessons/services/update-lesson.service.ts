import {
  doc,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";

import { db } from "@/lib/firebase/config";

import type { CreateLessonInput } from "../validators";

export async function updateLesson(
  lessonId: string,
  data: CreateLessonInput
): Promise<void> {
  await updateDoc(
    doc(db, "lessons", lessonId),
    {
      ...data,
      updatedAt: serverTimestamp(),
    }
  );
}