"use client";

import { useEffect, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Trash2 } from "lucide-react";
import { useFieldArray, useForm } from "react-hook-form";

import {
  FormActions,
  FormField,
  Input,
  Select,
  Textarea,
} from "@/components/ui";
import { MediaUploader } from "@/features/media/components";

import { DEFAULT_QUESTION } from "../constants";
import { createQuestionSchema } from "../validators";
import type { CreateQuestionInput } from "../validators";
import type { QuestionFormValues } from "../types";

interface CourseOption {
  id: string;
  title: string;
}

interface ChapterOption {
  id: string;
  name: string;
}

interface QuestionFormProps {
  mode?: "create" | "edit";
  initialValues?: Partial<QuestionFormValues>;
  courses?: CourseOption[];
  chapters?: ChapterOption[];
  loading?: boolean;
  submitLabel?: string;
  onSubmit?: (
    values: QuestionFormValues
  ) => Promise<void> | void;
  onCancel?: () => void;
}

function buildDefaultValues(
  initialValues?: Partial<QuestionFormValues>
): QuestionFormValues {
  return {
    courseId: initialValues?.courseId ?? "",
    chapterId: initialValues?.chapterId ?? "",
    title: initialValues?.title ?? "",
    imageUrl: initialValues?.imageUrl ?? "",
    explanation: initialValues?.explanation ?? "",
    explanationImageUrl:
      initialValues?.explanationImageUrl ?? "",
    type: initialValues?.type ?? "mcq",
    options: initialValues?.options?.length
      ? initialValues.options.map((option) => ({
          id: option.id || crypto.randomUUID(),
          text: option.text ?? "",
          imageUrl: option.imageUrl ?? "",
          isCorrect: Boolean(option.isCorrect),
        }))
      : DEFAULT_QUESTION.options.map((option) => ({
          ...option,
          id: option.id || crypto.randomUUID(),
          imageUrl: option.imageUrl ?? "",
        })),
    difficulty: initialValues?.difficulty ?? "medium",
    tags: initialValues?.tags ?? [],
    status: initialValues?.status ?? "draft",
  };
}

function parseTags(input: string): string[] {
  return input
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
}

export function QuestionForm({
  mode = "create",
  initialValues,
  courses = [],
  chapters = [],
  loading = false,
  submitLabel = mode === "edit" ? "Update Question" : "Create Question",
  onSubmit,
  onCancel,
}: QuestionFormProps) {
  const [tagInput, setTagInput] = useState(
    initialValues?.tags?.join(", ") ?? ""
  );

  const {
    control,
    register,
    handleSubmit,
    setValue,
    reset,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<CreateQuestionInput>({
    resolver: zodResolver(createQuestionSchema) as never,
    defaultValues: buildDefaultValues(initialValues),
    mode: "onSubmit",
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "options",
  });

  useEffect(() => {
    const nextValues = buildDefaultValues(initialValues);
    reset(nextValues);
    setTagInput((initialValues?.tags ?? []).join(", "));
  }, [initialValues, reset]);

  useEffect(() => {
    setValue("tags", parseTags(tagInput), {
      shouldValidate: true,
      shouldDirty: true,
    });
  }, [setValue, tagInput]);

  async function handleFormSubmit(values: CreateQuestionInput) {
    const payload: QuestionFormValues = {
      ...values,
      imageUrl: values.imageUrl ?? "",
      explanation: values.explanation ?? "",
      explanationImageUrl: values.explanationImageUrl ?? "",
      options: values.options.map((option) => ({
        ...option,
        imageUrl: option.imageUrl ?? "",
      })),
      tags: parseTags(tagInput),
    };

    await onSubmit?.(payload);
  }

  return (
    <form
      onSubmit={handleSubmit(handleFormSubmit)}
      className="space-y-6"
    >
      <div className="grid gap-4 md:grid-cols-2">
        <FormField
          label="Course"
          required
          error={errors.courseId?.message}
        >
          <Select
            {...register("courseId")}
            defaultValue={watch("courseId")}
          >
            <option value="">Select course</option>
            {courses.map((course) => (
              <option key={course.id} value={course.id}>
                {course.title}
              </option>
            ))}
          </Select>
        </FormField>

        <FormField
          label="Chapter"
          required
          error={errors.chapterId?.message}
        >
          <Select
            {...register("chapterId")}
            defaultValue={watch("chapterId")}
          >
            <option value="">Select chapter</option>
            {chapters.map((chapter) => (
              <option key={chapter.id} value={chapter.id}>
                {chapter.name}
              </option>
            ))}
          </Select>
        </FormField>
      </div>

      <FormField
        label="Question Title"
        required
        error={errors.title?.message}
      >
        <Input
          {...register("title")}
          placeholder="Enter the question title"
        />
      </FormField>

      <FormField label="Question Image">
        <MediaUploader
          folder="questions"
          value={watch("imageUrl")}
          onChange={(url) => {
            setValue("imageUrl", url, {
              shouldValidate: true,
              shouldDirty: true,
            });
          }}
        />
      </FormField>

      <FormField label="Explanation">
        <Textarea
          {...register("explanation")}
          rows={5}
          placeholder="Add a clear explanation for the correct answer"
        />
      </FormField>

      <FormField label="Explanation Image">
        <MediaUploader
          folder="questions"
          value={watch("explanationImageUrl")}
          onChange={(url) => {
            setValue("explanationImageUrl", url, {
              shouldValidate: true,
              shouldDirty: true,
            });
          }}
        />
      </FormField>

      <div className="grid gap-4 md:grid-cols-2">
        <FormField
          label="Type"
          required
          error={errors.type?.message}
        >
          <Select {...register("type")}>
            <option value="mcq">Multiple Choice</option>
            <option value="true_false">True / False</option>
            <option value="essay">Essay</option>
          </Select>
        </FormField>

        <FormField
          label="Difficulty"
          required
          error={errors.difficulty?.message}
        >
          <Select {...register("difficulty")}>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </Select>
        </FormField>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <FormField
          label="Status"
          required
          error={errors.status?.message}
        >
          <Select {...register("status")}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </Select>
        </FormField>

        <FormField label="Tags">
          <Input
            value={tagInput}
            onChange={(event) => setTagInput(event.target.value)}
            placeholder="biology, anatomy, pharmacy"
          />
          <p className="text-xs text-slate-500">
            Separate tags with commas.
          </p>
        </FormField>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-200">
            Options
          </h3>
          <button
            type="button"
            onClick={() =>
              append({
                id: crypto.randomUUID(),
                text: "",
                imageUrl: "",
                isCorrect: false,
              })
            }
            className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-3 py-2 text-sm text-slate-300 transition hover:bg-white/5"
          >
            <Plus size={16} />
            Add Option
          </button>
        </div>

        {fields.map((field, index) => (
          <div
            key={field.id}
            className="rounded-2xl border border-white/10 bg-navy-card/60 p-4"
          >
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm font-semibold text-slate-200">
                Option {index + 1}
              </p>
              {fields.length > 2 && (
                <button
                  type="button"
                  onClick={() => remove(index)}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-white/5 hover:text-red-400"
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>

            <div className="grid gap-4 md:grid-cols-[1fr_auto]">
              <FormField
                label={`Option ${index + 1}`}
                error={errors.options?.[index]?.text?.message}
              >
                <Input
                  {...register(`options.${index}.text` as const)}
                  placeholder={`Enter option ${index + 1}`}
                />
              </FormField>

              <FormField label="Correct Answer">
                <label className="flex h-full cursor-pointer items-center gap-2 rounded-xl border border-white/10 bg-navy-card px-4 py-3 text-sm text-slate-300">
                  <input
                    type="checkbox"
                    checked={Boolean(watch(`options.${index}.isCorrect`))}
                    onChange={(event) =>
                      setValue(
                        `options.${index}.isCorrect` as const,
                        event.target.checked,
                        {
                          shouldValidate: true,
                          shouldDirty: true,
                        }
                      )
                    }
                    className="h-4 w-4 rounded border-white/10 bg-transparent"
                  />
                  Mark as correct
                </label>
              </FormField>
            </div>

            <input
              type="hidden"
              {...register(`options.${index}.id` as const)}
            />
            <input
              type="hidden"
              {...register(`options.${index}.imageUrl` as const)}
            />
          </div>
        ))}

        {errors.options?.message && (
          <p className="text-sm text-red-400">
            {errors.options.message}
          </p>
        )}
      </div>

      <FormActions
        loading={loading || isSubmitting}
        submitLabel={submitLabel}
        onCancel={onCancel}
      />
    </form>
  );
}